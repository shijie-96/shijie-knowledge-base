/**
 * 星图返回的随机其他用户批次大小：
 * 本地演示版按 100 个测试账号设计，线上也统一返回 100 人，保证一进来就能看到满屏头像。
 * 仅影响「发现广度」，不构成任何排名、推荐或能力分层展示。
 */
export const STARMAP_BATCH_SIZE = 100;

/** 星图允许的最大批次上限（防止恶意超大） */
export const STARMAP_BATCH_MAX = 120;

/** 天气类型（氛围粒子效果） */
export const WEATHER_TYPES = ['clear', 'rain', 'snow', 'star'] as const;
export type WeatherType = (typeof WEATHER_TYPES)[number];

/** 天气偏好模式：跟随本地（按时间/季节自动）/ 自定义 */
export const WEATHER_MODES = ['local', 'custom'] as const;
export type WeatherMode = (typeof WEATHER_MODES)[number];

/** 引用连线返回上限（前端默认显示 ≤50 条，放大后最多显示 100 条） */
export const STARMAP_CONNECTION_LIMIT = 100;

/** 相似弱联系数量上限（更细虚线、数量更少） */
export const STARMAP_WEAK_LINK_LIMIT = 5;
